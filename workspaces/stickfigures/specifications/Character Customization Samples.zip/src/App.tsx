import { Card } from './components/ui/card';
import { ArmDisplay } from './components/ArmDisplay';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-slate-300 p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1>Fighter Arms Selection</h1>
          <p className="text-muted-foreground">Choose your arm type: from thin to huge muscles</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="p-6">
            <ArmDisplay level={1} name="Skinny Arms" />
          </Card>
          
          <Card className="p-6">
            <ArmDisplay level={2} name="Fit Arms" />
          </Card>
          
          <Card className="p-6">
            <ArmDisplay level={3} name="Strong Arms" />
          </Card>
          
          <Card className="p-6">
            <ArmDisplay level={4} name="Massive Arms" />
          </Card>
        </div>
      </div>
    </div>
  );
}
