interface ArmDisplayProps {
  level: 1 | 2 | 3 | 4;
  name: string;
}

export function ArmDisplay({ level, name }: ArmDisplayProps) {
  const getSkinBase = () => "#F4D7B8";
  const getSkinLight = () => "#FEECD8";
  const getSkinMid = () => "#E8C4A0";
  const getSkinDark = () => "#D4A574";
  const getSkinDeep = () => "#B88A5C";
  const getMuscleHighlight = () => "#FFF5E8";
  const getMuscleShadow = () => "#C49968";
  const getOutlineColor = () => "#3D2817";
  const getVeinColor = () => "#7B9DAA";

  // Calculate muscle dimensions based on level
  const getMuscle = () => {
    switch (level) {
      case 1:
        return {
          shoulder: 18,
          bicep: 12,
          forearm: 10,
          wrist: 8,
          definition: 0,
          veins: false,
        };
      case 2:
        return {
          shoulder: 24,
          bicep: 18,
          forearm: 14,
          wrist: 9,
          definition: 0.5,
          veins: false,
        };
      case 3:
        return {
          shoulder: 32,
          bicep: 26,
          forearm: 20,
          wrist: 11,
          definition: 0.8,
          veins: true,
        };
      case 4:
        return {
          shoulder: 42,
          bicep: 38,
          forearm: 28,
          wrist: 13,
          definition: 1.0,
          veins: true,
        };
      default:
        return {
          shoulder: 18,
          bicep: 12,
          forearm: 10,
          wrist: 8,
          definition: 0,
          veins: false,
        };
    }
  };

  const m = getMuscle();

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3>{name}</h3>
        <p className="text-sm text-muted-foreground">
          Level {level}
        </p>
      </div>

      <svg
        viewBox="0 0 120 280"
        className="w-full h-auto max-w-sm mx-auto"
      >
        <defs>
          {/* Gradients for realistic shading */}
          <radialGradient
            id={`shoulderGrad${level}`}
            cx="0.35"
            cy="0.35"
          >
            <stop
              offset="0%"
              stopColor={getMuscleHighlight()}
            />
            <stop offset="40%" stopColor={getSkinBase()} />
            <stop offset="100%" stopColor={getSkinMid()} />
          </radialGradient>

          <radialGradient
            id={`bicepGrad${level}`}
            cx="0.3"
            cy="0.3"
          >
            <stop
              offset="0%"
              stopColor={getMuscleHighlight()}
            />
            <stop offset="35%" stopColor={getSkinLight()} />
            <stop offset="70%" stopColor={getSkinBase()} />
            <stop offset="100%" stopColor={getSkinMid()} />
          </radialGradient>

          <radialGradient
            id={`forearmGrad${level}`}
            cx="0.35"
            cy="0.35"
          >
            <stop offset="0%" stopColor={getSkinLight()} />
            <stop offset="50%" stopColor={getSkinBase()} />
            <stop offset="100%" stopColor={getSkinMid()} />
          </radialGradient>

          <linearGradient
            id={`handGrad${level}`}
            x1="0%"
            y1="0%"
            x2="100%"
            y2="0%"
          >
            <stop offset="0%" stopColor={getSkinMid()} />
            <stop offset="40%" stopColor={getSkinBase()} />
            <stop offset="100%" stopColor={getSkinLight()} />
          </linearGradient>
        </defs>

        {/* Shoulder */}
        <ellipse
          cx="60"
          cy="20"
          rx={m.shoulder}
          ry={m.shoulder * 0.7}
          fill={`url(#shoulderGrad${level})`}
          stroke={getOutlineColor()}
          strokeWidth="2.5"
        />

        {/* Deltoid muscle definition */}
        {m.definition > 0.4 && (
          <>
            <path
              d={`M ${60 - m.shoulder * 0.6} ${20 + m.shoulder * 0.5} Q ${60 - m.shoulder * 0.3} ${20 + m.shoulder * 0.8}, 60 ${20 + m.shoulder * 0.7}`}
              fill="none"
              stroke={getMuscleShadow()}
              strokeWidth="1.5"
              opacity={m.definition * 0.5}
            />
            <path
              d={`M ${60 + m.shoulder * 0.6} ${20 + m.shoulder * 0.5} Q ${60 + m.shoulder * 0.3} ${20 + m.shoulder * 0.8}, 60 ${20 + m.shoulder * 0.7}`}
              fill="none"
              stroke={getMuscleShadow()}
              strokeWidth="1.5"
              opacity={m.definition * 0.5}
            />
          </>
        )}

        {/* Upper arm outline - inner edge */}
        <path
          d={`M ${60 - m.shoulder * 0.85} ${22 + m.shoulder * 0.3}
              Q ${60 - m.bicep * 1.15} 50, ${60 - m.bicep * 1.05} 75
              Q ${60 - m.bicep * 0.95} 92, ${60 - m.forearm * 0.75} 108
              Q ${60 - m.wrist * 0.85} 128, ${60 - m.wrist * 0.85} 142`}
          fill="none"
          stroke={getOutlineColor()}
          strokeWidth="2.5"
          strokeLinecap="round"
        />

        {/* Upper arm outline - outer edge */}
        <path
          d={`M ${60 + m.shoulder * 0.85} ${22 + m.shoulder * 0.3}
              Q ${60 + m.bicep * 0.65} 45, ${60 + m.bicep * 0.58} 75
              Q ${60 + m.bicep * 0.52} 92, ${60 + m.forearm * 0.55} 108
              Q ${60 + m.wrist * 0.65} 128, ${60 + m.wrist * 0.65} 142`}
          fill="none"
          stroke={getOutlineColor()}
          strokeWidth="2.5"
          strokeLinecap="round"
        />

        {/* Bicep brachii - main mass */}
        <ellipse
          cx={60 - m.bicep * 0.65}
          cy="58"
          rx={m.bicep * 0.85}
          ry={m.bicep * 1.4}
          fill={`url(#bicepGrad${level})`}
        />

        {/* Bicep peak highlight */}
        <ellipse
          cx={60 - m.bicep * 0.75}
          cy="53"
          rx={m.bicep * 0.45}
          ry={m.bicep * 0.9}
          fill={getMuscleHighlight()}
          opacity="0.7"
        />

        {/* Bicep separation line (between bicep heads) */}
        {m.definition > 0.4 && (
          <path
            d={`M ${60 - m.bicep * 0.4} 42 Q ${60 - m.bicep * 0.5} 58, ${60 - m.bicep * 0.35} 74`}
            fill="none"
            stroke={getMuscleShadow()}
            strokeWidth={1.5 + m.definition * 1.5}
            opacity={m.definition * 0.7}
            strokeLinecap="round"
          />
        )}

        {/* Bicep lateral definition */}
        {m.definition > 0.4 && (
          <path
            d={`M ${60 - m.bicep * 1.0} 48 Q ${60 - m.bicep * 1.08} 60, ${60 - m.bicep * 0.95} 72`}
            fill="none"
            stroke={getMuscleShadow()}
            strokeWidth={1.2 + m.definition}
            opacity={m.definition * 0.6}
            strokeLinecap="round"
          />
        )}

        {/* Inner bicep shadow */}
        <ellipse
          cx={60 - m.bicep * 0.35}
          cy="64"
          rx={m.bicep * 0.3}
          ry={m.bicep * 1.0}
          fill={getSkinDark()}
          opacity={0.35}
        />

        {/* Tricep (back of arm) */}
        <ellipse
          cx={60 + m.bicep * 0.28}
          cy="66"
          rx={m.bicep * 0.42}
          ry={m.bicep * 1.15}
          fill={getSkinMid()}
          opacity="0.85"
        />

        {/* Tricep definition */}
        {m.definition > 0.6 && (
          <>
            <path
              d={`M ${60 + m.bicep * 0.45} 52 Q ${60 + m.bicep * 0.35} 66, ${60 + m.bicep * 0.42} 78`}
              fill="none"
              stroke={getMuscleShadow()}
              strokeWidth={1 + m.definition}
              opacity={m.definition * 0.5}
            />
            <ellipse
              cx={60 + m.bicep * 0.15}
              cy="68"
              rx={m.bicep * 0.25}
              ry={m.bicep * 0.7}
              fill={getSkinDark()}
              opacity={0.3}
            />
          </>
        )}

        {/* Elbow region */}
        <ellipse
          cx={60 - m.forearm * 0.35}
          cy="100"
          rx={m.forearm * 0.75}
          ry={m.forearm * 0.7}
          fill={getSkinMid()}
          opacity="0.7"
        />

        {/* Elbow crease */}
        <path
          d={`M ${60 - m.forearm * 0.6} 98 Q ${60 - m.forearm * 0.35} 102, ${60 + m.forearm * 0.1} 100`}
          fill="none"
          stroke={getSkinDeep()}
          strokeWidth="1.5"
          opacity="0.6"
        />

        {/* Forearm - main mass */}
        <ellipse
          cx={60 - m.forearm * 0.52}
          cy="120"
          rx={m.forearm * 0.88}
          ry={m.forearm * 1.5}
          fill={`url(#forearmGrad${level})`}
        />

        {/* Forearm - back side */}
        <ellipse
          cx={60 + m.forearm * 0.25}
          cy="122"
          rx={m.forearm * 0.48}
          ry={m.forearm * 1.3}
          fill={getSkinMid()}
          opacity="0.75"
        />

        {/* Forearm extensors */}
        <ellipse
          cx={60 - m.forearm * 0.65}
          cy="116"
          rx={m.forearm * 0.45}
          ry={m.forearm * 1.0}
          fill={getMuscleHighlight()}
          opacity="0.55"
        />

        {/* Forearm muscle separations */}
        {m.definition > 0.5 && (
          <>
            <path
              d={`M ${60 - m.forearm * 0.35} 106 L ${60 - m.forearm * 0.4} 133`}
              fill="none"
              stroke={getMuscleShadow()}
              strokeWidth={1 + m.definition * 0.8}
              opacity={m.definition * 0.6}
              strokeLinecap="round"
            />
            <path
              d={`M ${60 - m.forearm * 0.75} 108 Q ${60 - m.forearm * 0.82} 120, ${60 - m.forearm * 0.75} 132`}
              fill="none"
              stroke={getMuscleShadow()}
              strokeWidth={0.8 + m.definition * 0.7}
              opacity={m.definition * 0.5}
              strokeLinecap="round"
            />
            <path
              d={`M ${60 - m.forearm * 0.2} 110 Q ${60 - m.forearm * 0.15} 122, ${60 - m.forearm * 0.18} 135`}
              fill="none"
              stroke={getMuscleShadow()}
              strokeWidth={0.8 + m.definition * 0.6}
              opacity={m.definition * 0.45}
              strokeLinecap="round"
            />
          </>
        )}

        {/* Veins for muscular levels */}
        {m.veins && (
          <>
            <path
              d={`M ${60 - m.forearm * 0.5} 110 Q ${60 - m.forearm * 0.45} 118, ${60 - m.forearm * 0.55} 128 Q ${60 - m.forearm * 0.5} 135, ${60 - m.forearm * 0.45} 140`}
              fill="none"
              stroke={getVeinColor()}
              strokeWidth={0.8 + level * 0.3}
              opacity={0.4 + m.definition * 0.2}
              strokeLinecap="round"
            />
            <path
              d={`M ${60 - m.bicep * 0.7} 70 Q ${60 - m.bicep * 0.8} 80, ${60 - m.bicep * 0.75} 88`}
              fill="none"
              stroke={getVeinColor()}
              strokeWidth={0.7 + level * 0.3}
              opacity={0.35 + m.definition * 0.15}
              strokeLinecap="round"
            />
          </>
        )}

        {/* Wrist */}
        <ellipse
          cx={60 - m.wrist * 0.35}
          cy="145"
          rx={m.wrist * 1.05}
          ry={m.wrist * 0.65}
          fill={getSkinBase()}
          stroke={getOutlineColor()}
          strokeWidth="2"
        />

        {/* Wrist bones/tendons visibility */}
        <ellipse
          cx={60 - m.wrist * 0.6}
          cy="144"
          rx={m.wrist * 0.35}
          ry={m.wrist * 0.4}
          fill={getSkinDark()}
          opacity="0.3"
        />
        <ellipse
          cx={60 + m.wrist * 0.1}
          cy="145"
          rx={m.wrist * 0.3}
          ry={m.wrist * 0.35}
          fill={getSkinDark()}
          opacity="0.25"
        />

        {/* Palm base */}
        <path
          d={`M ${60 - m.wrist * 0.9} 147
              L ${60 - m.wrist * 1.05} 175
              L ${60 + m.wrist * 0.35} 177
              L ${60 + m.wrist * 0.55} 148`}
          fill={`url(#handGrad${level})`}
          stroke={getOutlineColor()}
          strokeWidth="2.5"
        />

        {/* Thenar eminence (thumb muscle) */}
        <ellipse
          cx={60 - m.wrist * 0.75}
          cy="165"
          rx={m.wrist * 0.55}
          ry={m.wrist * 0.9}
          fill={getSkinLight()}
          opacity="0.7"
        />

        {/* Hypothenar eminence (pinky side) */}
        <ellipse
          cx={60 + m.wrist * 0.3}
          cy="168"
          rx={m.wrist * 0.4}
          ry={m.wrist * 0.8}
          fill={getSkinMid()}
          opacity="0.5"
        />

        {/* Palm creases */}
        <path
          d={`M ${60 - m.wrist * 0.85} 163 Q ${60 - m.wrist * 0.3} 166, ${60 + m.wrist * 0.2} 165`}
          fill="none"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.5"
          strokeLinecap="round"
        />
        <path
          d={`M ${60 - m.wrist * 0.9} 171 Q ${60 - m.wrist * 0.2} 174, ${60 + m.wrist * 0.25} 172`}
          fill="none"
          stroke={getSkinDeep()}
          strokeWidth="1"
          opacity="0.45"
          strokeLinecap="round"
        />

        {/* Thumb */}
        <path
          d={`M ${60 - m.wrist * 0.95} 157
              Q ${60 - m.wrist * 1.7} 164, ${60 - m.wrist * 1.78} 177
              Q ${60 - m.wrist * 1.72} 187, ${60 - m.wrist * 1.4} 190
              Q ${60 - m.wrist * 1.05} 185, ${60 - m.wrist * 0.92} 176`}
          fill={getSkinBase()}
          stroke={getOutlineColor()}
          strokeWidth="2.3"
        />

        {/* Thumb highlight */}
        <ellipse
          cx={60 - m.wrist * 1.6}
          cy="176"
          rx={m.wrist * 0.35}
          ry={m.wrist * 0.65}
          fill={getSkinLight()}
          opacity="0.6"
        />

        {/* Thumb joints */}
        <line
          x1={60 - m.wrist * 1.68}
          y1="177"
          x2={60 - m.wrist * 1.4}
          y2="178"
          stroke={getSkinDeep()}
          strokeWidth="1.3"
          opacity="0.6"
          strokeLinecap="round"
        />
        <ellipse
          cx={60 - m.wrist * 1.25}
          cy="167"
          rx={m.wrist * 0.25}
          ry={m.wrist * 0.2}
          fill={getSkinDark()}
          opacity="0.35"
        />

        {/* Index finger */}
        <path
          d={`M ${60 - m.wrist * 0.82} 177
              L ${60 - m.wrist * 0.92} 204
              Q ${60 - m.wrist * 0.88} 210, ${60 - m.wrist * 0.75} 213
              Q ${60 - m.wrist * 0.55} 214, ${60 - m.wrist * 0.42} 211
              Q ${60 - m.wrist * 0.38} 206, ${60 - m.wrist * 0.35} 201
              L ${60 - m.wrist * 0.22} 177`}
          fill={getSkinBase()}
          stroke={getOutlineColor()}
          strokeWidth="2.3"
        />

        {/* Index finger segments and shading */}
        <ellipse
          cx={60 - m.wrist * 0.6}
          cy="188"
          rx={m.wrist * 0.22}
          ry={m.wrist * 0.45}
          fill={getSkinLight()}
          opacity="0.5"
        />
        <line
          x1={60 - m.wrist * 0.88}
          y1="190"
          x2={60 - m.wrist * 0.28}
          y2="189"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.55"
          strokeLinecap="round"
        />
        <line
          x1={60 - m.wrist * 0.85}
          y1="201"
          x2={60 - m.wrist * 0.35}
          y2="200"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.55"
          strokeLinecap="round"
        />

        {/* Index fingernail */}
        <ellipse
          cx={60 - m.wrist * 0.65}
          cy="209"
          rx={m.wrist * 0.15}
          ry={m.wrist * 0.25}
          fill={getSkinLight()}
          opacity="0.8"
        />

        {/* Middle finger */}
        <path
          d={`M ${60 - m.wrist * 0.22} 177
              L ${60 - m.wrist * 0.28} 217
              Q ${60 - m.wrist * 0.22} 223, ${60 - m.wrist * 0.05} 225
              Q ${60 + m.wrist * 0.12} 224, ${60 + m.wrist * 0.18} 218
              Q ${60 + m.wrist * 0.18} 213, ${60 + m.wrist * 0.15} 206
              L ${60 + m.wrist * 0.12} 177`}
          fill={getSkinBase()}
          stroke={getOutlineColor()}
          strokeWidth="2.3"
        />

        {/* Middle finger segments and shading */}
        <ellipse
          cx={60 - m.wrist * 0.05}
          cy="195"
          rx={m.wrist * 0.24}
          ry={m.wrist * 0.55}
          fill={getSkinLight()}
          opacity="0.5"
        />
        <line
          x1={60 - m.wrist * 0.25}
          y1="193"
          x2={60 + m.wrist * 0.12}
          y2="192"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.55"
          strokeLinecap="round"
        />
        <line
          x1={60 - m.wrist * 0.22}
          y1="209"
          x2={60 + m.wrist * 0.15}
          y2="208"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.55"
          strokeLinecap="round"
        />

        {/* Middle fingernail */}
        <ellipse
          cx={60 - m.wrist * 0.08}
          cy="220"
          rx={m.wrist * 0.16}
          ry={m.wrist * 0.28}
          fill={getSkinLight()}
          opacity="0.8"
        />

        {/* Ring finger */}
        <path
          d={`M ${60 + m.wrist * 0.12} 177
              L ${60 + m.wrist * 0.05} 209
              Q ${60 + m.wrist * 0.12} 215, ${60 + m.wrist * 0.25} 217
              Q ${60 + m.wrist * 0.38} 216, ${60 + m.wrist * 0.42} 210
              Q ${60 + m.wrist * 0.42} 204, ${60 + m.wrist * 0.38} 198
              L ${60 + m.wrist * 0.37} 177`}
          fill={getSkinBase()}
          stroke={getOutlineColor()}
          strokeWidth="2.3"
        />

        {/* Ring finger segments and shading */}
        <ellipse
          cx={60 + m.wrist * 0.22}
          cy="192"
          rx={m.wrist * 0.22}
          ry={m.wrist * 0.5}
          fill={getSkinLight()}
          opacity="0.5"
        />
        <line
          x1={60 + m.wrist * 0.08}
          y1="191"
          x2={60 + m.wrist * 0.36}
          y2="190"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.55"
          strokeLinecap="round"
        />
        <line
          x1={60 + m.wrist * 0.1}
          y1="202"
          x2={60 + m.wrist * 0.38}
          y2="201"
          stroke={getSkinDeep()}
          strokeWidth="1.2"
          opacity="0.55"
          strokeLinecap="round"
        />

        {/* Ring fingernail */}
        <ellipse
          cx={60 + m.wrist * 0.2}
          cy="213"
          rx={m.wrist * 0.15}
          ry={m.wrist * 0.26}
          fill={getSkinLight()}
          opacity="0.8"
        />

        {/* Pinky finger */}
        <path
          d={`M ${60 + m.wrist * 0.37} 177
              L ${60 + m.wrist * 0.3} 199
              Q ${60 + m.wrist * 0.35} 204, ${60 + m.wrist * 0.46} 206
              Q ${60 + m.wrist * 0.58} 205, ${60 + m.wrist * 0.6} 200
              Q ${60 + m.wrist * 0.58} 195, ${60 + m.wrist * 0.55} 190
              L ${60 + m.wrist * 0.52} 177`}
          fill={getSkinBase()}
          stroke={getOutlineColor()}
          strokeWidth="2.3"
        />

        {/* Pinky segments and shading */}
        <ellipse
          cx={60 + m.wrist * 0.45}
          cy="187"
          rx={m.wrist * 0.2}
          ry={m.wrist * 0.42}
          fill={getSkinLight()}
          opacity="0.5"
        />
        <line
          x1={60 + m.wrist * 0.33}
          y1="188"
          x2={60 + m.wrist * 0.53}
          y2="187"
          stroke={getSkinDeep()}
          strokeWidth="1.1"
          opacity="0.55"
          strokeLinecap="round"
        />
        <line
          x1={60 + m.wrist * 0.35}
          y1="197"
          x2={60 + m.wrist * 0.55}
          y2="196"
          stroke={getSkinDeep()}
          strokeWidth="1.1"
          opacity="0.55"
          strokeLinecap="round"
        />

        {/* Pinky fingernail */}
        <ellipse
          cx={60 + m.wrist * 0.42}
          cy="202"
          rx={m.wrist * 0.13}
          ry={m.wrist * 0.22}
          fill={getSkinLight()}
          opacity="0.8"
        />

        {/* Knuckle details on palm */}
        <ellipse
          cx={60 - m.wrist * 0.65}
          cy="176"
          rx={m.wrist * 0.22}
          ry={m.wrist * 0.18}
          fill={getSkinDark()}
          opacity="0.25"
        />
        <ellipse
          cx={60 - m.wrist * 0.15}
          cy="176"
          rx={m.wrist * 0.24}
          ry={m.wrist * 0.2}
          fill={getSkinDark()}
          opacity="0.25"
        />
        <ellipse
          cx={60 + m.wrist * 0.22}
          cy="176"
          rx={m.wrist * 0.22}
          ry={m.wrist * 0.18}
          fill={getSkinDark()}
          opacity="0.25"
        />
        <ellipse
          cx={60 + m.wrist * 0.48}
          cy="176"
          rx={m.wrist * 0.18}
          ry={m.wrist * 0.15}
          fill={getSkinDark()}
          opacity="0.25"
        />
      </svg>
    </div>
  );
}