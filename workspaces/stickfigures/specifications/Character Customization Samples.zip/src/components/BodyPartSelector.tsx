import { BodyPart } from '../data/bodyParts';
import { Card } from './ui/card';

interface BodyPartSelectorProps {
  bodyParts: BodyPart[];
  selectedPart: BodyPart | null;
  onSelect: (part: BodyPart) => void;
  label: string;
}

export function BodyPartSelector({ bodyParts, selectedPart, onSelect, label }: BodyPartSelectorProps) {
  const getTierColor = (tier: number) => {
    switch (tier) {
      case 1:
        return 'border-gray-400 bg-gray-50';
      case 2:
        return 'border-blue-400 bg-blue-50';
      case 3:
        return 'border-purple-400 bg-purple-50';
      case 4:
        return 'border-orange-400 bg-orange-50';
      default:
        return 'border-gray-400 bg-gray-50';
    }
  };

  const getTierLabel = (tier: number) => {
    switch (tier) {
      case 1:
        return 'Weak';
      case 2:
        return 'Strong';
      case 3:
        return 'Very Strong';
      case 4:
        return 'Super Strong';
      default:
        return '';
    }
  };

  return (
    <div className="space-y-3">
      <h3 className="text-center">{label}</h3>
      <div className="grid grid-cols-2 gap-3">
        {bodyParts.map((part) => (
          <Card
            key={part.id}
            className={`p-3 cursor-pointer transition-all border-2 ${
              selectedPart?.id === part.id
                ? 'ring-2 ring-offset-2 ring-green-500 scale-105'
                : ''
            } ${getTierColor(part.tier)} hover:scale-105`}
            onClick={() => onSelect(part)}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-3xl">{part.icon}</span>
                <span className="text-xs px-2 py-1 rounded bg-white/50">
                  Tier {part.tier}
                </span>
              </div>
              <div>
                <div className="font-medium">{part.name}</div>
                <div className="text-xs text-muted-foreground">{getTierLabel(part.tier)}</div>
              </div>
              <div className="text-xs space-y-1">
                <div className="flex justify-between">
                  <span>⚔️ Power:</span>
                  <span>{part.power}</span>
                </div>
                <div className="flex justify-between">
                  <span>🛡️ Defense:</span>
                  <span>{part.defense}</span>
                </div>
                <div className="flex justify-between">
                  <span>⚡ Speed:</span>
                  <span>{part.speed}</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground italic">{part.description}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
