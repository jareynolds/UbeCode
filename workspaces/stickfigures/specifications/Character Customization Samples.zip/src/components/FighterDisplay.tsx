import { BodyPart } from '../data/bodyParts';
import { Card } from './ui/card';
import { Progress } from './ui/progress';

interface FighterDisplayProps {
  head: BodyPart | null;
  arms: BodyPart | null;
  body: BodyPart | null;
  legs: BodyPart | null;
  playerName: string;
}

export function FighterDisplay({ head, arms, body, legs, playerName }: FighterDisplayProps) {
  const totalPower = (head?.power || 0) + (arms?.power || 0) + (body?.power || 0) + (legs?.power || 0);
  const totalDefense = (head?.defense || 0) + (arms?.defense || 0) + (body?.defense || 0) + (legs?.defense || 0);
  const totalSpeed = (head?.speed || 0) + (arms?.speed || 0) + (body?.speed || 0) + (legs?.speed || 0);

  const maxStat = 225; // Maximum possible total for any stat

  const isComplete = head && arms && body && legs;

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="text-center">
          <h3>{playerName}</h3>
          <p className="text-sm text-muted-foreground">
            {isComplete ? 'Fighter Ready!' : 'Select all body parts'}
          </p>
        </div>

        <div className="bg-gradient-to-b from-gray-100 to-gray-200 rounded-lg p-6 min-h-[280px] flex flex-col items-center justify-center">
          <div className="space-y-1 text-center">
            <div className="text-5xl">{head?.icon || '❔'}</div>
            <div className="text-4xl">{arms?.icon || '❔'}</div>
            <div className="text-5xl">{body?.icon || '❔'}</div>
            <div className="text-4xl">{legs?.icon || '❔'}</div>
          </div>
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm">⚔️ Total Power</span>
              <span className="text-sm">{totalPower}</span>
            </div>
            <Progress value={(totalPower / maxStat) * 100} className="h-2" />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm">🛡️ Total Defense</span>
              <span className="text-sm">{totalDefense}</span>
            </div>
            <Progress value={(totalDefense / maxStat) * 100} className="h-2" />
          </div>

          <div>
            <div className="flex justify-between mb-1">
              <span className="text-sm">⚡ Total Speed</span>
              <span className="text-sm">{totalSpeed}</span>
            </div>
            <Progress value={(totalSpeed / maxStat) * 100} className="h-2" />
          </div>

          <div className="pt-2 border-t">
            <div className="flex justify-between">
              <span>Overall Rating</span>
              <span className="font-medium">{totalPower + totalDefense + totalSpeed}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2 bg-gray-50 rounded">
            <div className="text-muted-foreground">Head</div>
            <div>{head?.name || 'Not selected'}</div>
          </div>
          <div className="p-2 bg-gray-50 rounded">
            <div className="text-muted-foreground">Arms</div>
            <div>{arms?.name || 'Not selected'}</div>
          </div>
          <div className="p-2 bg-gray-50 rounded">
            <div className="text-muted-foreground">Body</div>
            <div>{body?.name || 'Not selected'}</div>
          </div>
          <div className="p-2 bg-gray-50 rounded">
            <div className="text-muted-foreground">Legs</div>
            <div>{legs?.name || 'Not selected'}</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
