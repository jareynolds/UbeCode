export interface BodyPart {
  id: string;
  name: string;
  tier: 1 | 2 | 3 | 4;
  type: 'arms' | 'legs' | 'body' | 'head';
  power: number;
  defense: number;
  speed: number;
  description: string;
  icon: string;
}

export const armsOptions: BodyPart[] = [
  {
    id: 'arms-1',
    name: 'Skinny Arms',
    tier: 1,
    type: 'arms',
    power: 10,
    defense: 5,
    speed: 15,
    description: 'Weak punches but quick strikes',
    icon: '💪🏻',
  },
  {
    id: 'arms-2',
    name: 'Trained Arms',
    tier: 2,
    type: 'arms',
    power: 25,
    defense: 15,
    speed: 20,
    description: 'Balanced power and speed',
    icon: '💪',
  },
  {
    id: 'arms-3',
    name: 'Mechanical Arms',
    tier: 3,
    type: 'arms',
    power: 45,
    defense: 30,
    speed: 25,
    description: 'Enhanced cybernetic strength',
    icon: '🦾',
  },
  {
    id: 'arms-4',
    name: 'Titan Arms',
    tier: 4,
    type: 'arms',
    power: 70,
    defense: 50,
    speed: 30,
    description: 'Devastating crushing power',
    icon: '⚡',
  },
];

export const legsOptions: BodyPart[] = [
  {
    id: 'legs-1',
    name: 'Thin Legs',
    tier: 1,
    type: 'legs',
    power: 8,
    defense: 5,
    speed: 20,
    description: 'Fast movement but weak kicks',
    icon: '🦵🏻',
  },
  {
    id: 'legs-2',
    name: 'Athletic Legs',
    tier: 2,
    type: 'legs',
    power: 20,
    defense: 15,
    speed: 35,
    description: 'Good mobility and kick strength',
    icon: '🦵',
  },
  {
    id: 'legs-3',
    name: 'Spring Legs',
    tier: 3,
    type: 'legs',
    power: 35,
    defense: 25,
    speed: 55,
    description: 'Incredible agility and jumping',
    icon: '🦿',
  },
  {
    id: 'legs-4',
    name: 'Rocket Legs',
    tier: 4,
    type: 'legs',
    power: 60,
    defense: 40,
    speed: 80,
    description: 'Supersonic speed with explosive kicks',
    icon: '🚀',
  },
];

export const bodyOptions: BodyPart[] = [
  {
    id: 'body-1',
    name: 'Frail Torso',
    tier: 1,
    type: 'body',
    power: 5,
    defense: 10,
    speed: 10,
    description: 'Vulnerable to attacks',
    icon: '👕',
  },
  {
    id: 'body-2',
    name: 'Fit Torso',
    tier: 2,
    type: 'body',
    power: 15,
    defense: 30,
    speed: 15,
    description: 'Decent endurance and protection',
    icon: '🦺',
  },
  {
    id: 'body-3',
    name: 'Armored Torso',
    tier: 3,
    type: 'body',
    power: 25,
    defense: 60,
    speed: 10,
    description: 'Heavy plated protection',
    icon: '🛡️',
  },
  {
    id: 'body-4',
    name: 'Fortress Torso',
    tier: 4,
    type: 'body',
    power: 40,
    defense: 100,
    speed: 15,
    description: 'Nearly impenetrable defense',
    icon: '🏰',
  },
];

export const headOptions: BodyPart[] = [
  {
    id: 'head-1',
    name: 'Basic Head',
    tier: 1,
    type: 'head',
    power: 5,
    defense: 8,
    speed: 5,
    description: 'No special abilities',
    icon: '😐',
  },
  {
    id: 'head-2',
    name: 'Tactical Helmet',
    tier: 2,
    type: 'head',
    power: 15,
    defense: 25,
    speed: 10,
    description: 'Enhanced awareness and protection',
    icon: '⛑️',
  },
  {
    id: 'head-3',
    name: 'Cybernetic Head',
    tier: 3,
    type: 'head',
    power: 30,
    defense: 45,
    speed: 20,
    description: 'Advanced targeting systems',
    icon: '🤖',
  },
  {
    id: 'head-4',
    name: 'Dragon Head',
    tier: 4,
    type: 'head',
    power: 55,
    defense: 65,
    speed: 25,
    description: 'Breathes fire and intimidates enemies',
    icon: '🐲',
  },
];

export const allBodyParts = {
  arms: armsOptions,
  legs: legsOptions,
  body: bodyOptions,
  head: headOptions,
};
