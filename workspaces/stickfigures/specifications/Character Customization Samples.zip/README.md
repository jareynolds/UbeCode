
  # Character Customization Samples

  This is a code bundle for Character Customization Samples. The original project is available at https://www.figma.com/design/XYGUV3IqEURsMotKewk83q/Character-Customization-Samples.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  